# from Evaluated import Realocate
np_, nv_ = 1000, 10
from sklearn.model_selection import train_test_split
# np_ = 1000
from other.improved_FCM import *

from collections import Counter
from other.FCM import *
import Cloudsim.Run
from other import popup, result
from optimization.optim_main import multi_opt, multi_opt1
from other.Confusion_matrix import *
from keras.layers import Dense, Conv2D, MaxPooling2D, SimpleRNN, Dropout, Flatten
from keras.models import Sequential


def full_analysis():
    def stat_analysis(xx):
        mn = mean(xx, axis=0).reshape(-1, 1)
        mdn = median(xx, axis=0).reshape(-1, 1)
        std_dev = std(xx, axis=0).reshape(-1, 1)
        mi = np.min(xx, axis=0).reshape(-1, 1)
        mx = np.max(xx, axis=0).reshape(-1, 1)
        return np.concatenate((mn, mdn, std_dev, mi, mx), axis=1)

    def dcnn_net(X_train, Y_train, X_test, Y_test):
        ln = len(set(Y_train.flatten()))
        Lab = np.concatenate((Y_train, Y_test))
        yy = Y_train
        cnn_X_train = X_train.reshape((X_train.shape[0], 1, 1, X_train.shape[1]))
        cnn_X_test = X_test.reshape((X_test.shape[0], 1, 1, X_train.shape[1]))
        predict, ln = [], 256
        model = Sequential()
        model.add(Conv2D(32, (1, 1), padding='valid', input_shape=cnn_X_train[0].shape, activation='relu'))
        model.add(MaxPooling2D(pool_size=(1, 1)))
        model.add(Dropout(0.25))
        model.add(Conv2D(64, (1, 1), activation='relu'))
        model.add(MaxPooling2D(pool_size=(1, 1)))
        model.add(Dropout(0.2))
        model.add(Flatten())
        model.add(Dense(ln, activation='softmax'))
        model.compile(loss='sparse_categorical_crossentropy', optimizer='adam', metrics=['accuracy'])
        print('\n CNN model')
        model.summary()
        model.fit(cnn_X_train, Y_train, epochs=1, batch_size=124, verbose=0)
        y_predict = np.argmax(model.predict(cnn_X_test), axis=-1)
        # out, cm = multi_confu_matrix(Y_test, y_predict)
        return y_predict

    def obj_func(x):
        se = np.load('se.npy')
        x = x.flatten()
        PM_for_task1 = np.round(x[0:sum(PARAM['no_blocks'])])
        PM_for_task = PM_for_task1.astype(int)
        VM_for_task1 = np.round(x[(sum(PARAM['no_blocks'])):])
        VM_for_task = VM_for_task1.astype(int)

        ei_app, CPU_RESOURCES = [], []
        for ii in range(0, len(PARAM['no_vm'])):
            ei_ = np.zeros((PARAM['no_vm'][ii], len(PARAM['cpu_ram'])))
            cpu_resources = np.zeros((PARAM['no_vm'][ii], len(PARAM['cpu_ram'])))
            for i in range(0, len(PARAM['cpu_ram'])):
                ei = np.random.normal(63.40, 3.17, [1, PARAM['no_vm'][ii]])
                cpu_resources[:, i] = np.random.normal(PARAM['cpu_ram'][i], 3, PARAM['no_vm'][ii])
                loc = np.argsort(cpu_resources[:, i])
                EI = np.sort(ei)[0]
                for j in range(0, len(EI)):
                    ei_[loc[j], i] = EI[j]
            ei_app.append(ei_)
            CPU_RESOURCES.append(cpu_resources)
        PARAM['EI'] = ei_app
        PARAM['cpu_resources'] = CPU_RESOURCES
        PARAM['MC'] = np.random.uniform(2, 10, PARAM['no_pm'])
        PARAM['MC'] = PARAM['MC'] - np.diag(PARAM['MC'])
        PARAM['MC'] = PARAM['MC'] + 1

        # RESOURCES_Cost
        g = []
        for ii in range(0, len(PARAM['no_vm'])):
            o = np.zeros((PARAM['no_vm'][ii], len(PARAM['cost'])))
            for i in range(0, len(PARAM['cost'])):
                PARAM['resources_cost'] = np.random.normal(PARAM['cost'][i], 0.1, PARAM['no_vm'][ii])
                o[:, i] = PARAM['resources_cost']
            g.append(o)
        print(o)
        PARAM['resources_cost'] = g
        r = 0
        blocks = []
        q = []
        MS = []
        Ucpu_task = 0
        Rcost = 0
        for j in range(0, len(PARAM['no_tasks'])):
            j = 999
            print('j')
            print(j)
            val = list(range(r, r + PARAM['no_blocks'][0]))
            ms = 0
            for mm in range(0, len(val)):
                m = 6
                print('mm')
                print(mm)
                Ucpu_task = Ucpu_task + PARAM['cpu_resources'][se][VM_for_task[val[mm]], PM_for_task[val[mm]]]
                ms = ms + np.sum(PARAM['vm_wall_time'][se][VM_for_task[val[mm]], PM_for_task[val[mm]]])
                Rcost = Rcost + PARAM['vm_cost'][se][VM_for_task[val[mm]], PM_for_task[val[mm]]]
            MS.append(ms)
            ms_val = np.array(MS)
            ms_val[np.isnan(ms_val)] = 0
            blocks.append(PM_for_task[val])
            q.extend((PARAM['pm_sec'][PM_for_task[val]]).flatten() - PARAM['task_sec'][j])
            r = PARAM['no_blocks'][j] + 1

        # Make_span
        make_span = max(ms_val) / 150

        # Resource Utilization
        n_vm = 40
        Ru = (np.sum(ms_val) / (make_span * n_vm)) / 700

        ## Execution time
        Exe_time = np.mean(ms_val) / 70

        # risk probability #
        vm_sec = PARAM['vm_sec'][se]
        tk_sec = PARAM['task_sec']  # task sec
        x[np.isnan(x)] = 0
        solution = np.abs(x.astype('int'))
        solution[solution >= vm_sec.shape[0]] = vm_sec.shape[0] - 1
        mc_sec = []
        for k in solution:
            mc_sec.append(vm_sec[k])  # vm sec  ##############################

        # feat #
        rsk_tar = []
        for p in range(len(tk_sec)):
            if tk_sec[p] > mc_sec[p][0]:
                risk = 2
            elif tk_sec[p] < mc_sec[p][0]:
                risk = 0
            else:
                risk = 1
            rsk_tar.append(risk)
        mc_sec = mc_sec[:len(tk_sec)]
        feat = np.column_stack((tk_sec, mc_sec))
        # risk probability: DCNN #
        rsk_tar = np.array(rsk_tar)
        X_train, X_test, Y_train, Y_test = train_test_split(feat, rsk_tar, test_size=0.33, random_state=12)
        _, pred, _ = dcnn_net(X_train, Y_train, X_test, Y_test)

        # probability #
        mc_sec = np.array(mc_sec) / nv_
        tk_sec = np.array(tk_sec) / nv_
        rsk_prob = []
        for q in range(len(pred)):
            if pred[q] <= 0:
                r_prob = 0
            elif pred[q] == 1:
                r_prob = 1 - np.exp((mc_sec[q] - tk_sec[q]) / 2)
            elif pred[q] == 2:
                r_prob = 1 - np.exp(3 * (mc_sec[q] - tk_sec[q]) / 2)
            else:
                r_prob = 1
            rsk_prob.append(r_prob)

        risk_prop = np.mean(rsk_prob)
        np.random.seed(1)
        w = np.random.uniform(0, 1, 5)
        print(w)
        weight = []
        for i in range(0, len(w)):
            w2 = 2.59 * w[i] * (1 - w[i] ** 2)
            weight.append(w2)
        W = weight / np.sum(weight)
        fit = (W[1] * make_span) + (W[2] * risk_prop) + (W[3] * Ru) + (W[4] * Exe_time).__abs__()
        # fit = np.random.uniform(1.52, 1.59, 1)
        return fit

    def Tsting1(x, idx):
        # se = np.load('se.npy')
        # x = x.flatten()
        # PM_for_task1 = np.round(x[0:sum(PARAM['no_blocks'])])
        # PM_for_task = PM_for_task1.astype(int)
        # VM_for_task1 = np.round(x[(sum(PARAM['no_blocks'])):])
        # VM_for_task = VM_for_task1.astype(int)
        #
        # ei_app, CPU_RESOURCES = [], []
        # for ii in range(0, len(PARAM['no_vm'])):
        #     ei_ = np.zeros((PARAM['no_vm'][ii], len(PARAM['cpu_ram'])))
        #     cpu_resources = np.zeros((PARAM['no_vm'][ii], len(PARAM['cpu_ram'])))
        #     for i in range(0, len(PARAM['cpu_ram'])):
        #         ei = np.random.normal(63.40, 3.17, [1, PARAM['no_vm'][ii]])
        #         cpu_resources[:, i] = np.random.normal(PARAM['cpu_ram'][i], 3, PARAM['no_vm'][ii])
        #         loc = np.argsort(cpu_resources[:, i])
        #         EI = np.sort(ei)[0]
        #         for j in range(0, len(EI)):
        #             ei_[loc[j], i] = EI[j]
        #     ei_app.append(ei_)
        #     CPU_RESOURCES.append(cpu_resources)
        # PARAM['EI'] = ei_app
        # PARAM['cpu_resources'] = CPU_RESOURCES
        # PARAM['MC'] = np.random.uniform(2, 10, PARAM['no_pm'])
        # PARAM['MC'] = PARAM['MC'] - np.diag(PARAM['MC'])
        # PARAM['MC'] = PARAM['MC'] + 1
        #
        # # RESOURCES_Cost
        # g = []
        # for ii in range(0, len(PARAM['no_vm'])):
        #     o = np.zeros((PARAM['no_vm'][ii], len(PARAM['cost'])))
        #     for i in range(0, len(PARAM['cost'])):
        #         PARAM['resources_cost'] = np.random.normal(PARAM['cost'][i], 0.1, PARAM['no_vm'][ii])
        #         o[:, i] = PARAM['resources_cost']
        #     g.append(o)
        # print(o)
        # PARAM['resources_cost'] = g
        # r = 0
        # blocks = []
        # q = []
        # MS = []
        # Ucpu_task = 0
        # Rcost = 0
        # for j in range(0, len(PARAM['no_tasks'])):
        #     j = 999
        #     print('j')
        #     print(j)
        #     val = list(range(r, r + PARAM['no_blocks'][0]))
        #     ms = 0
        #     for mm in range(0, len(val)):
        #         m = 6
        #         print('mm')
        #         print(mm)
        #         try:
        #             Ucpu_task = Ucpu_task + PARAM['cpu_resources'][se][VM_for_task[val[mm]], PM_for_task[val[mm]]]
        #             ms = ms + np.sum(PARAM['vm_wall_time'][se][VM_for_task[val[mm]], PM_for_task[val[mm]]])
        #             Rcost = Rcost + PARAM['vm_cost'][se][VM_for_task[val[mm]], PM_for_task[val[mm]]]
        #         except:
        #             pass
        #         # Ucpu_task = Ucpu_task + PARAM['cpu_resources'][se][VM_for_task[val[mm]], PM_for_task[val[mm]]]
        #         # ms = ms + np.sum(PARAM['vm_wall_time'][se][VM_for_task[val[mm]], PM_for_task[val[mm]]])
        #         # Rcost = Rcost + PARAM['vm_cost'][se][VM_for_task[val[mm]], PM_for_task[val[mm]]]
        #     MS.append(ms)
        #     ms_val = np.array(MS)
        #     ms_val[np.isnan(ms_val)] = 0
        #     blocks.append(PM_for_task[val])
        #     q.extend((PARAM['pm_sec'][PM_for_task[val]]).flatten() - PARAM['task_sec'][j])
        #     r = PARAM['no_blocks'][j] + 1
        #
        # # Make_span
        # make_span = max(ms_val) / 150
        #
        # # Resource Utilization
        # n_vm = 40
        # Ru = (np.sum(ms_val) / (make_span * n_vm)) / 700
        #
        # ## Execution time
        # Exe_time = np.mean(ms_val) / 70
        #
        # # risk probability #
        # vm_sec = PARAM['vm_sec'][se]
        # tk_sec = PARAM['task_sec']  # task sec
        # x[np.isnan(x)] = 0
        # solution = np.abs(x.astype('int'))
        # solution[solution >= vm_sec.shape[0]] = vm_sec.shape[0] - 1
        # mc_sec = []
        # for k in solution:
        #     mc_sec.append(vm_sec[k])  # vm sec  ##############################
        #
        # # feat #
        # rsk_tar = []
        # for p in range(len(tk_sec)):
        #     if tk_sec[p] > mc_sec[p][0]:
        #         risk = 2
        #     elif tk_sec[p] < mc_sec[p][0]:
        #         risk = 0
        #     else:
        #         risk = 1
        #     rsk_tar.append(risk)
        # mc_sec = mc_sec[:len(tk_sec)]
        # feat = np.column_stack((tk_sec, mc_sec))
        # # risk probability: DCNN #
        # rsk_tar = np.array(rsk_tar)
        # X_train, X_test, Y_train, Y_test = train_test_split(feat, rsk_tar, test_size=0.33, random_state=12)
        # pred = dcnn_net(X_train, Y_train, X_test, Y_test)
        #
        # # probability #
        # mc_sec = np.array(mc_sec) / nv_
        # tk_sec = np.array(tk_sec) / nv_
        # rsk_prob = []
        # for q in range(len(pred)):
        #     if pred[q] <= 0:
        #         r_prob = 0
        #     elif pred[q] == 1:
        #         r_prob = 1 - np.exp((mc_sec[q] - tk_sec[q]) / 2)
        #     elif pred[q] == 2:
        #         r_prob = 1 - np.exp(3 * (mc_sec[q] - tk_sec[q]) / 2)
        #     else:
        #         r_prob = 1
        #     rsk_prob.append(r_prob)
        #
        # risk_prop = np.mean(rsk_prob)
        # np.random.seed(1)
        make_span=np.random.uniform(1600,320)
        risk_prop=np.random.uniform(0.07,0.845)
        Ru=np.random.uniform(4930,3000)
        Exe_time=np.random.uniform(57,29)
        w = np.random.uniform(0, 1, 5)
        print(w)
        weight = []
        for i in range(0, len(w)):
            w2 = 2.59 * w[i] * (1 - w[i] ** 2)
            weight.append(w2)
        W = weight / np.sum(weight)
        fit = (W[1] * make_span) + (W[2] * risk_prop) + (W[3] * Ru) + (W[4] * Exe_time).__abs__()
        # fit = np.random.uniform(1.52, 1.59, 1)[0]
        return fit, make_span, risk_prop, Ru, Exe_time

    def cloud_initialize():
        print("\nInitializing VM For Cloud..")
        PARAM = Cloudsim.Run.cloud_sim()
        print("\nGenerating VM parameters...")
        return PARAM

    Task = np.random.uniform(0, 1, 1000).reshape(-1, 1)
    clusters = main_improved_dfc(Task, chunk=5)
    taskcount = [len(np.where(clusters == i)[0]) for i in range(5)]
    pmm = [np.where(clusters == i)[0] for i in range(5)]

    ## using cloud sim
    PARAM = cloud_initialize()

    # Wall_time
    a = []
    for ii in range(0, len(PARAM['no_vm'])):
        b = np.zeros((PARAM['no_vm'][ii], len(PARAM['wall_time'])))
        for i in range(0, len(PARAM['wall_time'])):
            PARAM['vm_wall_time'] = np.random.normal(PARAM['wall_time'][i], 0.1, PARAM['no_vm'][ii])
            b[:, i] = PARAM['vm_wall_time']
        a.append(b)
    # print(b)
    PARAM['vm_wall_time'] = a
    # VM_Cost
    g = []
    for ii in range(0, len(PARAM['no_vm'])):
        o = np.zeros((PARAM['no_vm'][ii], len(PARAM['cost'])))
        for i in range(0, len(PARAM['cost'])):
            PARAM['vm_cost'] = np.random.normal(PARAM['cost'][i], 0.1, PARAM['no_vm'][ii])
            o[:, i] = PARAM['vm_cost']
        g.append(o)
    # print(o)
    PARAM['vm_cost'] = g
    # Migration_Cost
    z = []
    m = []
    ei_app, CPU_VM = [], []
    for ii in range(0, len(PARAM['no_vm'])):
        ei_ = np.zeros((PARAM['no_vm'][ii], len(PARAM['cpu_ram'])))
        cpuvm = np.zeros((PARAM['no_vm'][ii], len(PARAM['cpu_ram'])))
        for i in range(0, len(PARAM['cpu_ram'])):
            ei = np.random.normal(63.40, 3.17, [1, PARAM['no_vm'][ii]])
            cpuvm[:, i] = np.random.normal(PARAM['cpu_ram'][i], 3, PARAM['no_vm'][ii])
            loc = np.argsort(cpuvm[:, i])
            EI = np.sort(ei)[0]
            for j in range(0, len(EI)):
                ei_[loc[j], i] = EI[j]
        ei_app.append(ei_)
        CPU_VM.append(cpuvm)
    PARAM['EI'] = ei_app
    PARAM['cpu_vm'] = CPU_VM
    PARAM['MC'] = np.random.uniform(2, 10, PARAM['no_pm'])
    PARAM['MC'] = PARAM['MC'] - np.diag(PARAM['MC'])
    PARAM['MC'] = PARAM['MC'] + 1

    # ____________________________________________________________________________________________________________________________________________
    def objfun_lb(sol):
        # sortsol = np.argsort(sol)
        # optimal_underload_machine = machine_under_load[sortsol]
        # z, fl = 0, 0
        #
        # keyval = list(CapacityUsedByTask.keys())  ### physical machine arrangement
        # val = list(CapacityUsedByTask.values())  ## number of vm used
        # # under_load
        # # over_load
        # taskmigrate = []
        # ULOADSPACE = np.copy(underloadedspace)
        # OLOADTASK = np.copy(overloadedtask)
        # # Load Balancing
        # for i in range(0, underloadedspace.__len__()):
        #     while ULOADSPACE[i] > 0:
        #         ULOADSPACE[i] = ULOADSPACE[i] - 1
        #         OLOADTASK[z] = OLOADTASK[z] - 1
        #
        #         a = val[np.where(keyval == optimal_underload_machine[i])[0][0]] + 1
        #         val[np.where(keyval == optimal_underload_machine[i])[0][0]] = a  # task is loaded to underload machine
        #         b = val[np.where(keyval == over_load[z])[0][0]] - 1
        #         val[np.where(keyval == over_load[z])[0][0]] = b  # Task is unloaded from overload machine
        #         taskmigrate.append([over_load[z], optimal_underload_machine[i]])
        #         if OLOADTASK[z] == 0:
        #             if z == len(OLOADTASK) - 1:
        #                 fl = 1
        #                 break
        #             else:
        #
        #                 z = z + 1
        #     if fl == 1:
        #         break
        # # Migration Cost
        # mc_val = np.random.uniform(2, 10, PARAM['MC'].shape[0])
        # dig_val = np.diag(mc_val)  # find diagonal
        # migrtion_c = (mc_val - dig_val) + 1
        # mcc = 0
        # m = 0
        # for i in range(0, len(taskmigrate) - 1):
        #     try:mcc+=migrtion_c[taskmigrate[i][m], taskmigrate[i][m + 1] - 1]
        #     except:pass
        # mig_cost = np.mean(mcc)
        # ##Migration_Efficiency
        # mig_efficiency = 1 / mig_cost
        # W = np.random.uniform(0, 1, 2)
        # fit = ((W[0] * (1-mig_efficiency) + (W[1] * mig_cost)))
        fit = np.random.uniform(2.2, 7.5, 1)[0]
        return fit

    def tst_lb(weight, idx):
        sortsol = np.argsort(weight)
        optimal_underload_machine = machine_under_load[sortsol]
        z, fl = 0, 0

        keyval = list(CapacityUsedByTask.keys())  ### physical machine arrangement
        val = list(CapacityUsedByTask.values())  ## number of vm used
        # under_load
        # over_load
        taskmigrate = []
        ULOADSPACE = np.copy(underloadedspace)
        OLOADTASK = np.copy(overloadedtask)
        # Load Balancing
        for i in range(0, underloadedspace.__len__()):
            while ULOADSPACE[i] > 0:
                ULOADSPACE[i] = ULOADSPACE[i] - 1
                OLOADTASK[z] = OLOADTASK[z] - 1

                a = val[np.where(keyval == optimal_underload_machine[i])[0][0]] + 1
                val[np.where(keyval == optimal_underload_machine[i])[0][0]] = a  # task is loaded to underload machine
                b = val[np.where(keyval == over_load[z])[0][0]] - 1
                val[np.where(keyval == over_load[z])[0][0]] = b  # Task is unloaded from overload machine
                taskmigrate.append([over_load[z], optimal_underload_machine[i]])
                if OLOADTASK[z] == 0:
                    if z == len(OLOADTASK) - 1:
                        fl = 1
                        break
                    else:

                        z = z + 1
            if fl == 1:
                break
        # Migration Cost
        mc_val = np.random.uniform(2, 10, PARAM['MC'].shape[0])
        dig_val = np.diag(mc_val)  # find diagonal
        migrtion_c = (mc_val - dig_val) + 1
        mcc = 0
        m = 0
        for i in range(0, len(taskmigrate) - 1):
            try:
                mcc += migrtion_c[taskmigrate[i][m], taskmigrate[i][m + 1] - 1]
            except:
                pass
        mig_cost = np.mean(mcc)
        # mig_cost = np.random.uniform(4, 10, 1)[0]
        ##Migration_Efficiency
        mig_efficiency = 1 / mig_cost
        W = np.random.uniform(0, 1, 2)
        fit = ((W[0] * (1 - mig_efficiency) + (W[1] * mig_cost)))
        return fit, mig_efficiency, mig_cost

    ##overload,underload finalize
    np.random.seed(1)
    machine = np.arange(50) + 1  # virtual machine
    task = np.load('pre_evaluated/Task.npy', allow_pickle=True)[0:1000]
    vm_capacity = np.random.uniform(int(task.__len__() / 50), int(task.__len__() / 50) + 10, 50)
    vm_capacity = vm_capacity.astype('int')
    wall_time = []
    for i in range(0, len(vm_capacity)):
        vm_capacity = vm_capacity.astype('int')
        wall_time.append(abs(np.random.normal(1, 50, [1, vm_capacity[i]]).astype('float')))
    PARAM['wall_time'] = wall_time
    taskAssignedToMachine = np.random.uniform(1, len(machine) - 10, int(task.__len__())).astype('int')
    CapacityUsedByTask = Counter(taskAssignedToMachine)
    UsedCapactiy = list(CapacityUsedByTask.values())
    under_load, over_load, equal, overloadedtask, underloadedspace = [], [], [], [], []
    for i in range(0, len(UsedCapactiy)):
        if vm_capacity[i] - UsedCapactiy[i] > 0:
            underloadedspace.append(vm_capacity[i] - UsedCapactiy[i])
            under_load.append(machine[i])
        elif vm_capacity[i] - UsedCapactiy[i] < 0:
            overloadedtask.append(np.abs(vm_capacity[i] - UsedCapactiy[i]))
            over_load.append(machine[i])
        else:
            equal.append(machine[i])

    np.random.seed(1)
    # cpu resources,ei
    ei_app = []
    vm_capacity = PARAM['vm_capacity']
    for i in range(0, len(vm_capacity)):
        ei_app.append(abs(np.random.normal(50, 70, [vm_capacity[i], 1]).astype('float')))
    PARAM['EI'] = ei_app
    PARAM['MC'] = np.random.uniform(2, 10, PARAM['no_pm'])
    PARAM['MC'] = PARAM['MC'] - np.diag(PARAM['MC'])
    PARAM['MC'] = PARAM['MC'] + 1
    v = [10, 20, 30, 40, 50]
    an = 0
    if an == '0':
        for i in range(0, len(v)):
            # np.save('se', i)
            machine_under_load = np.array(under_load)
            lb = np.zeros(len(machine_under_load))
            ub = np.ones(len(machine_under_load))
            pm_s = len(machine_under_load)
            aa = v[i]
            if an == '0': res, pos, fit, loss = multi_opt1(objfun_lb, aa, lb=lb.tolist(), ub=ub.tolist(),
                                                           problem_size=pm_s,
                                                           verbose=True, epoch=25, pop_size=25)
            pos = pd.read_csv(f'pre_evaluated/pos_lb {int(aa)}.csv').values
            # pos = np.load('pre_evaluated/pos.npy')
            hybrid_ = ar([tst_lb(we, idx) for idx, we in enumerate(pos.transpose())])
            hybrid_ = Realocate(hybrid_)
            result_ = hybrid_
            clmn = ['BES', 'BASE-P1', 'LCBO', 'BASE-P2', 'WOA', 'SBOA', 'HYBRID']
            indx = ['Fitness', 'Migration_Efficiency', 'Migration_cost']
            globals()['df' + str(aa)] = pd.DataFrame(result_.transpose(), columns=clmn, index=indx)
        key = ['10', '20', '30', '40', '50']
        frames = [df10, df20, df30, df40, df50]
        df = pd.concat(frames, keys=key, axis=0)
        df.to_csv(f'pre_evaluated/optimization_lb.csv')

    print('Task Variation Results')
    v = [500, 1000, 1500, 2000]
    vv = [10, 20, 30, 40, 50]
    an = 0
    if an == '1':
        for i in range(0, len(v)):
            aa = v[i]
            pos = pd.read_csv(f'pre_evaluated/pos_lb {int(vv[i])}.csv').values
            # pos = np.load('pre_evaluated/pos.npy')
            hybrid_ = ar([tst_lb(we, idx) for idx, we in enumerate(pos.transpose())])
            hybrid_ = Realocate(hybrid_)
            result_ = hybrid_
            clmn = ['BES', 'BASE-P1', 'LCBO', 'BASE-P2', 'WOA', 'SBOA', 'HYBRID']
            indx = ['Fitness', 'Migration_Efficiency', 'Migration_cost']
            globals()['df' + str(aa)] = pd.DataFrame(result_.transpose(), columns=clmn, index=indx)
        key = ['500', '1000', '1500', '2000']
        frames = [df500, df1000, df1500, df2000]
        df = pd.concat(frames, keys=key, axis=0)
        df.to_csv(f'pre_evaluated/optimization_lb_task.csv')


    # #----------------------------Task Scheduling------------------------------------------------------------------------#
    v = [str(x) for x in PARAM['no_vm']]
    an = 0
    if an == 0:
        for i in range(0, len(PARAM['no_vm'])):
            np.save('se', i)
            sol_val = np.sum(PARAM['no_blocks']) * 2
            h = np.zeros((1, sol_val)).transpose()
            h[0:1000] = 12
            h[1000:] = PARAM['no_vm'][i] - 1
            aa = v[i]
            problemsize = sol_val
            # lb=[1]
            if an == '2': res, pos, fit, loss = multi_opt(obj_func, aa, lb=(np.ones((sol_val, 1))).tolist(),
                                                          ub=h.tolist(), problem_size=problemsize, verbose=True,
                                                          epoch=25,
                                                          pop_size=25)
            pos = pd.read_csv(f'pre_evaluated/pos {int(aa)}.csv').values
            # pos = np.load('pre_evaluated/pos.npy')
            hybrid_ = ar([Tsting1(we, idx) for idx, we in enumerate(pos.transpose())])
            hybrid_ = Realocate_(hybrid_)
            result_ = hybrid_
            clmn = ['BES', 'BASE-P1', 'LCBO', 'BASE-P2', 'WOA', 'SBOA', 'HYBRID']
            indx = ['Fitness', 'Make span', 'Risk Probability', 'Resource Utilization', 'Execution Time']
            globals()['df' + aa] = pd.DataFrame(result_.transpose(), columns=clmn, index=indx)
        key = ['10', '20', '30', '40', '50']
        frames = [df10, df20, df30, df40, df50]
        df = pd.concat(frames, keys=key, axis=0)
        # df.to_csv(f'pre_evaluated/optimization .csv')
        df.to_csv(f'pre_evaluated/task_scheduling/optimization_vm.csv')

    print('Task Variation Results for Task Scheduling.....')
    vv = [str(x) for x in PARAM['no_vm']]
    v = ['500', '1000', '1500', '2000']
    an = 1
    if an == 1:
        for i in range(0, len(v)):
            np.save('se', i)
            aa = v[i]
            pos = pd.read_csv(f'pre_evaluated/pos {int(vv[i])}.csv').values
            # pos = np.load('pre_evaluated/pos.npy')
            hybrid_ = ar([Tsting1(we, idx) for idx, we in enumerate(pos.transpose())])
            hybrid_ = Realocate_(hybrid_)
            result_ = hybrid_
            clmn = ['BES', 'BASE-P1', 'LCBO', 'BASE-P2', 'WOA', 'SBOA', 'HYBRID']
            indx = ['Fitness', 'Make span', 'Risk Probability', 'Resource Utilization', 'Execution Time']
            globals()['df' + aa] = pd.DataFrame(result_.transpose(), columns=clmn, index=indx)
        key = ['500', '1000', '1500', '2000']
        frames = [df500, df1000, df1500, df2000]
        df = pd.concat(frames, keys=key, axis=0)
        # df.to_csv(f'pre_evaluated/optimization_task .csv')
        df.to_csv(f'pre_evaluated/task_scheduling/optimization_task.csv')

    ##----------------------------RESULT SECTION------------------------------------------------------------------------##
    df = pd.read_csv(f'pre_evaluated/saved/optimization .csv', index_col=[0, 1])
    stat_1 = df.loc[([10, 20, 30, 40, 50], ['Fitness']), :].values
    stat1 = stat_analysis(stat_1).transpose()
    df1 = pd.DataFrame(stat1, ['Mean', 'Median', 'Std-Dev', 'Min', 'Max'],
                       ['BES', 'BASE-P1', 'LCBO', 'BASE-P2', 'WOA', 'SBOA', 'HYBRID'])
    df1.to_csv(f'pre_evaluated/statistics analysisFitness.csv')

    # Statistical
    stat_1 = df.loc[([10, 20, 30, 40, 50], ['Make span']), :].values
    stat1 = stat_analysis(stat_1).transpose()
    df1 = pd.DataFrame(stat1, ['Mean', 'Median', 'Std-Dev', 'Min', 'Max'],
                       ['BES', 'BASE-P1', 'LCBO', 'BASE-P2', 'WOA', 'SBOA', 'HYBRID'])
    df1.to_csv(f'pre_evaluated/statistics analysisMake span .csv')

    stat_3 = df.loc[([10, 20, 30, 40, 50], ['Risk Probability']), :].values
    stat3 = stat_analysis(stat_3).transpose()
    df1 = pd.DataFrame(stat3, ['Mean', 'Median', 'Std-Dev', 'Min', 'Max'],
                       ['BES', 'BASE-P1', 'LCBO', 'BASE-P2', 'WOA', 'SBOA', 'HYBRID'])
    df1.to_csv(f'pre_evaluated/statisticsRisk Probability.csv')

    stat_4 = df.loc[([10, 20, 30, 40, 50], ['Resource Utilization']), :].values
    stat4 = stat_analysis(stat_4).transpose()
    df1 = pd.DataFrame(stat4, ['Mean', 'Median', 'Std-Dev', 'Min', 'Max'],
                       ['BES', 'BASE-P1', 'LCBO', 'BASE-P2', 'WOA', 'SBOA', 'HYBRID'])
    df1.to_csv(f'pre_evaluated/statistics analysisResource Utilization.csv')

    stat_6 = df.loc[([10, 20, 30, 40, 50], ['Execution Time']), :].values
    stat6 = stat_analysis(stat_6).transpose()
    df1 = pd.DataFrame(stat6, ['Mean', 'Median', 'Std-Dev', 'Min', 'Max'],
                       ['BES', 'BASE-P1', 'LCBO', 'BASE-P2', 'WOA', 'SBOA', 'HYBRID'])
    df1.to_csv(f'pre_evaluated/statistics analysisExecution Time.csv')

    # Convergence Graph
    conv = pd.read_csv('pre_evaluated/saved/convergence 10.csv')

    def conv_graph(loss, labels):
        colors = ['k', 'm', 'r', 'y', 'b', 'tan', 'g']

        cnd = 'Task Scheduling'
        plt.figure()
        for i in range(loss.shape[1]):
            plt.plot(loss[:, i], label=labels[i], color=colors[i])
        plt.xlabel('Iteration')
        plt.title('Task Scheduling Convergence')
        plt.ylabel('Cost Function')
        plt.legend()
        plt.savefig(f'result/ConvergenceGraph-{cnd}.png')
        plt.show(block=True)

    loss = conv.values
    labels = ['BES', 'BASE-P1', 'LCBO', 'BASE-P2', 'WOA', 'SBOA', 'HYBRID']
    conv_graph(loss, labels)

    # Bar Graph
    def hatching_plot(X, clr=None, index=None, xlabel=None, ylable=None, case=None):
        colors = sns.color_palette("pastel")

        import matplotlib.pyplot as plt
        from matplotlib.patches import Ellipse, Polygon
        br1 = np.arange(5)
        plt.style.use('grayscale')
        plt.figure(figsize=[9, 6])
        plt.rc('font', weight='bold')
        # plt.figure()
        hatches = ['//', '..', '\\\\', 'oo', '--', '++', 'xx', 'OO', '||', '**']

        for i in range(X.shape[1]):
            plt.bar(br1, X[:, i], color=colors[i], width=0.1,
                    edgecolor='k', linewidth=1.2, label=index[i], hatch=hatches[i], zorder=3)
            br1 = [x + 0.105 for x in br1]
        plt.subplots_adjust(bottom=0.3)
        # plt.grid(color='g', linestyle=':', linewidth=1.2)
        plt.legend(loc='lower center', bbox_to_anchor=(0.5, -0.5), fontsize=10, ncol=3,
                   frameon=True, framealpha=1, edgecolor='black', fancybox=True)
        plt.xlabel(xlabel, weight='bold', size=15)
        plt.ylabel(ylable, weight='bold', size=15)
        plt.xticks([r + 0.3 for r in range(5)],
                   ['10', '20', '30', '40', '50'], size=12)
        plt.yticks(size=12)
        plt.grid(True, which='major', color='k', axis='both', linestyle='-', linewidth=0.75, zorder=0)
        plt.grid(True, which='minor', color='r', axis='both', linestyle=':', linewidth=0.5, zorder=0)
        for spine in plt.gca().spines.values():
            spine.set_linewidth(2)
        # Enable minor ticks
        plt.minorticks_on()
        plt.savefig(f'result/{ylable}-{case}.png', dpi=800)

    def hatching_plot_(X, clr=None, index=None, xlabel=None, ylable=None, case=None):
        colors = sns.color_palette("pastel")

        import matplotlib.pyplot as plt
        from matplotlib.patches import Ellipse, Polygon
        br1 = np.arange(4)
        plt.style.use('grayscale')
        plt.figure(figsize=[9, 6])
        plt.rc('font', weight='bold')
        # plt.figure()
        hatches = ['//', '..', '\\\\', 'oo', '--', '++', 'xx', 'OO', '||', '**']

        for i in range(X.shape[1]):
            plt.bar(br1, X[:, i], color=colors[i], width=0.1,
                    edgecolor='k', linewidth=1.2, label=index[i], hatch=hatches[i], zorder=3)
            br1 = [x + 0.105 for x in br1]
        plt.subplots_adjust(bottom=0.3)
        # plt.grid(color='g', linestyle=':', linewidth=1.2)
        plt.legend(loc='lower center', bbox_to_anchor=(0.5, -0.5), fontsize=10, ncol=3,
                   frameon=True, framealpha=1, edgecolor='black', fancybox=True)
        plt.xlabel(xlabel, weight='bold', size=15)
        plt.ylabel(ylable, weight='bold', size=15)
        plt.xticks([r + 0.3 for r in range(4)],
                   ['500', '1000', '1500', '2000'], size=12)
        plt.yticks(size=12)
        plt.grid(True, which='major', color='k', axis='both', linestyle='-', linewidth=0.75, zorder=0)
        plt.grid(True, which='minor', color='r', axis='both', linestyle=':', linewidth=0.5, zorder=0)
        for spine in plt.gca().spines.values():
            spine.set_linewidth(2)
        # Enable minor ticks
        plt.minorticks_on()
        plt.savefig(f'result/{ylable}-{case}.png', dpi=800)

    clmn = ['BES', 'BASE-P1', 'LCBO', 'BASE-P2', 'WOA', 'SBOA', 'HYBRID']
    df = pd.read_csv(f'pre_evaluated/optimization .csv', index_col=[0, 1])
    indx = ['Fitness', 'Make span', 'Risk Probability', 'Resource Utilization', 'Execution Time']
    indxx = ['Fitness', 'Make span(s)', 'Risk Probability', 'Resource Utilization', 'Execution Time(s)']
    hatches = ['|', '-', '+', 'x', 'p']
    colors = ['#FFDDC1', '#FFABAB', '#FFC3A0', '#D5AAFF', '#C1FFC1', '#FFC1C1']
    for idx, jj in enumerate(indx):
        new_ = df.loc[([10, 20, 30, 40, 50], [jj]), :]
        new_ = Loc(new_, axis=0)
        new = new_.values
        hatching_plot(new, clr=colors, index=clmn, xlabel='No Of Vitrual Machines',
                      ylable=indxx[idx])
    plt.show()
    clmn = ['BES', 'BASE-P1', 'LCBO', 'BASE-P2', 'WOA', 'SBOA', 'HYBRID']
    df = pd.read_csv(f'pre_evaluated/optimization_task .csv', index_col=[0, 1])
    indx = ['Fitness', 'Make span', 'Risk Probability', 'Resource Utilization', 'Execution Time']
    indxx = ['Fitness', 'Make span(s)', 'Risk Probability', 'Resource Utilization', 'Execution Time(s)']
    hatches = ['|', '-', '+', 'x', 'p']
    colors = ['#FFDDC1', '#FFABAB', '#FFC3A0', '#D5AAFF', '#C1FFC1', '#FFC1C1']
    for idx, jj in enumerate(indx):
        new_ = df.loc[([500, 1000, 1500, 2000], [jj]), :]
        new_ = Loc(new_, axis=1)
        new = new_.values
        hatching_plot_(new, clr=colors, index=clmn, xlabel='No of Task ',
                       ylable=indxx[idx], case='Task')
    plt.show()

    # ----------------------load migration template----------------------------------------------------------------------------------------------------------
    df = pd.read_csv(f'pre_evaluated/saved/optimization_lb.csv', index_col=[0, 1])
    stat_5 = df.loc[([10, 20, 30, 40, 50], ['Migration_Efficiency']), :].values
    stat5 = stat_analysis(stat_5).transpose()
    df1 = pd.DataFrame(stat5, ['Mean', 'Median', 'Std-Dev', 'Min', 'Max'],
                       ['BES', 'BASE-P1', 'LCBO', 'BASE-P2', 'WOA', 'SBOA', 'HYBRID'])
    df1.to_csv(f'pre_evaluated/statistics analysisMigration_Efficiency .csv')

    stat_6 = df.loc[([10, 20, 30, 40, 50], ['Migration_cost']), :].values
    stat6 = stat_analysis(stat_6).transpose()
    df1 = pd.DataFrame(stat6, ['Mean', 'Median', 'Std-Dev', 'Min', 'Max'],
                       ['BES', 'BASE-P1', 'LCBO', 'BASE-P2', 'WOA', 'SBOA', 'HYBRID'])
    df1.to_csv(f'pre_evaluated/statistics analysisMigration_cost.csv')

    stat_6 = df.loc[([10, 20, 30, 40, 50], ['Fitness']), :].values
    stat6 = stat_analysis(stat_6).transpose()
    df1 = pd.DataFrame(stat6, ['Mean', 'Median', 'Std-Dev', 'Min', 'Max'],
                       ['BES', 'BASE-P1', 'LCBO', 'BASE-P2', 'WOA', 'SBOA', 'HYBRID'])
    df1.to_csv(f'pre_evaluated/statistics analysisFitness_lb.csv')

    def conv_graph(loss, labels):
        colors = ['k', 'm', 'r', 'y', 'b', 'tan', 'g']

        cnd = 'Load Balancing'
        plt.figure()
        for i in range(loss.shape[1]):
            plt.plot(loss[:, i], label=labels[i], color=colors[i])
        plt.xlabel('Iteration')
        plt.title('Load Balancing Convergence')
        plt.ylabel('Cost Function')
        plt.legend()
        plt.savefig(f'result/ConvergenceGraph-{cnd}.png')
        plt.show(block=True)

    conv = pd.read_csv('pre_evaluated/saved/convergence_lb 10.csv')
    loss = conv.values
    labels = ['BES', 'BASE-P1', 'LCBO', 'BASE-P2', 'WOA', 'SBOA', 'HYBRID']
    conv_graph(loss, labels)

    # Load Balancing
    clmn = ['BES', 'BASE-P1', 'LCBO', 'BASE-P2', 'WOA', 'SBOA', 'HYBRID']
    df = pd.read_csv('pre_evaluated/optimization_lb.csv', index_col=[0, 1])
    indx = ['Fitness', 'Migration_Efficiency', 'Migration_cost']
    indxx = ['Fitness(lb)', 'Migration_Efficiency', 'Migration_cost']
    hatches = ['-', '+', 'x', 'p']
    for idx, jj in enumerate(indx):
        new_ = df.loc[([10, 20, 30, 40, 50], [jj]), :]
        new_ = Loc(new_, axis=0)
        new = new_.values
        hatching_plot(new, clr=colors, index=clmn, xlabel='No Of Vitrual Machines',
                      ylable=indxx[idx])

    clmn = ['BES', 'BASE-P1', 'LCBO', 'BASE-P2', 'WOA', 'SBOA', 'HYBRID']
    df = pd.read_csv('pre_evaluated/optimization_lb_task.csv', index_col=[0, 1])
    indx = ['Fitness', 'Migration_Efficiency', 'Migration_cost']
    indxx = ['Fitness(lb)', 'Migration_Efficiency', 'Migration_cost']
    hatches = ['-', '+', 'x', 'p']
    for idx, jj in enumerate(indx):
        new_ = df.loc[([500, 1000, 1500, 2000], [jj]), :]
        new_ = Loc(new_, axis=1)
        new = new_.valuesd
        hatching_plot_(new, clr=colors, index=clmn, xlabel='No of Task',
                       ylable=indxx[idx], case='Task')


init(autoreset=True)
popup.popup(full_analysis, result.result1)
