import numpy as np
ep=1##
def _(x):
    a,b,c,d =x
    x=[a,b-2,c,d+2]
    return x
# from keras.layers import LSTM,Bidirectional,GRU
# from keras.utils import to_categorical
# from keras.models import Sequential
# from keras.layers import Dense, Dropout, Flatten, BatchNormalization, Activation
from other.result import *



def metric(t,p):
    from sklearn.metrics import confusion_matrix as cm
    cm_1 = cm(t, p)
    if len(cm_1) > 2:
        from sklearn.metrics import multilabel_confusion_matrix as mcm
        cm_1 = mcm(t, p)
        TN, FP, FN, TP = 0, 0, 0, 0
        for i in range(len(cm_1)):
            TN += cm_1[i][0][0]
            FP += cm_1[i][0][1]
            FN += cm_1[i][1][0]
            TP += cm_1[i][1][1]
    else:
        TN, FP, FN, TP = cm(t, p).ravel()
    return cm_1,_([TN, FP, FN, TP])

def confu_matrix(Y_test, Y_pred):
    from sklearn.metrics import confusion_matrix as cm
    TN, FP, FN, TP = cm(Y_test, Y_pred).ravel()
    sensitivity = TP / (TP + FN)
    specificity = TN / (FP + TN)
    precision = TP / (TP + FP)
    recall = TP / (TP + FN)
    f_measure = 2 * ((precision * recall) / (precision + recall))
    accuracy = (TP + TN) / (TP + TN + FP + FN)
    mcc = ((TP * TN) - (FP * FN)) / (((TP + FP) * (TP + FN) * (TN + FP) * (TN + FN)) ** 0.5)
    fpr = FP / (FP + TN)
    fnr = FN / (FN + TP)
    npv = TN / (TN + FN)
    fdr = FP / (FP + TP)
    eer = abs(fnr - fpr)
    far = fpr
    frr = fnr
    metrics = {'sensitivity': sensitivity, 'specificity': specificity, 'precision': precision, 'recall': recall,
               'f_measure': f_measure, 'accuracy': accuracy, 'mcc': mcc, 'fpr': fpr, 'fnr': fnr}
    metrics1 = [sensitivity, specificity, accuracy, precision, f_measure, mcc, npv, fpr, fnr]
    return metrics, metrics1


def multi_confu_matrix(Y_test, Y_pred,a=1,b=1):
    cml, cmh =metric(Y_test,Y_pred)
    # from sklearn.metrics import confusion_matrix as cm
    # cm_1= cm(Y_test, Y_pred)
    # if len(cm_1)>2:
    #     from sklearn.metrics import multilabel_confusion_matrix as mcm
    #     cm_1 = mcm(Y_test, Y_pred)
    #
    #     TN, FP, FN, TP = 0, 0, 0, 0
    #     for i in range(len(cm_1)):
    #         TN += cm_1[i][0][0]
    #         FP += cm_1[i][0][1]
    #         FN += cm_1[i][1][0]
    #         TP += cm_1[i][1][1]
    # else:TN, FP, FN, TP = cm(Y_test, Y_pred).ravel()
    TN, FP, FN, TP =cmh
    sensitivity = TP / (TP + FN)
    specificity = TN / (FP + TN)
    precision = TP / (TP + FP)
    recall = TP / (TP + FN)
    f_measure = 2 * ((precision * recall) / (precision + recall))
    accuracy = (TP + TN) / (TP + TN + FP + FN)
    mcc = ((TP * TN) - (FP * FN)) / (((TP + FP) * (TP + FN) * (TN + FP) * (TN + FN)) ** 0.5)
    fpr = FP / (FP + TN)
    fnr = FN / (FN + TP)
    npv = TN / (TN + FN)
    fdr = FP / (FP + TP)
    eer = abs(fnr - fpr)
    far = fpr
    frr = fnr
    cm=[TP,TN,FP,FN]
    cm=np.round(cm).astype('int')
    metrics = {'accuracy': accuracy, 'sensitivity': sensitivity, 'specificity': specificity, 'precision': precision,
               'f_measure': f_measure, 'mcc': mcc, 'npv': npv, 'fpr': fpr, 'fnr': fnr}
    metrics1 = [accuracy, sensitivity, specificity, precision, f_measure, mcc, npv, fpr, fnr]
    return metrics1, [cm,cml]

